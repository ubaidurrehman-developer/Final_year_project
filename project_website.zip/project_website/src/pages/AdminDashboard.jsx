import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Activity, TrendingUp, Cpu, FileBox, Upload, FileText } from 'lucide-react';
import AnalyticsDashboard from '../components/AnalyticsDashboard';
import { useForms } from '../context/FormContext';

const AdminDashboard = () => {
    const [activeTab, setActiveTab] = useState('overview');
    const { agents, templates, generatedForms, uploadTemplate } = useForms();

    const handleFileUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            uploadTemplate(file);
        }
    };

    return (
        <div className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 lg:px-8 py-6 sm:py-10">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 sm:mb-8 gap-3 sm:gap-4">
                <div>
                    <h1 className="text-2xl sm:text-3xl font-bold text-[var(--page-text)]">Admin Portal</h1>
                    <p className="text-sm sm:text-base text-[var(--text-muted)] mt-1">System overview and form management</p>
                </div>
                <div className="flex bg-[var(--glass-bg)] backdrop-blur-lg p-0.5 sm:p-1 rounded-xl sm:rounded-2xl border border-[var(--glass-border)] overflow-x-auto max-w-full w-full md:w-auto">
                    {[
                        { id: 'overview', label: 'Overview', icon: <Activity className="h-4 w-4" /> },
                        { id: 'analytics', label: 'Analytics', icon: <TrendingUp className="h-4 w-4" /> },
                        { id: 'agents', label: 'Agent Monitor', icon: <Cpu className="h-4 w-4" /> },
                        { id: 'templates', label: 'Templates', icon: <FileBox className="h-4 w-4" /> }
                    ].map((tab) => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`flex items-center gap-1.5 sm:gap-2 px-3 py-2 sm:px-4 sm:py-2.5 rounded-lg sm:rounded-xl transition-all font-medium text-xs sm:text-sm whitespace-nowrap min-h-[44px] ${activeTab === tab.id
                                ? 'bg-primary-600 text-white shadow-lg shadow-primary-500/20'
                                : 'text-[var(--text-muted)] hover:text-[var(--page-text)] hover:bg-[var(--glass-bg)]'
                                }`}
                        >
                            <span className="w-4 h-4 flex-shrink-0">{tab.icon}</span>
                            <span className="hidden xs:inline sm:inline">{tab.label}</span>
                        </button>
                    ))}
                </div>
            </div>

            {activeTab === 'overview' && (
                <div className="bg-[var(--card-bg)] backdrop-blur-xl p-4 sm:p-6 rounded-2xl sm:rounded-3xl shadow-lg border border-[var(--glass-border)]">
                    <h2 className="text-lg sm:text-xl font-bold text-[var(--page-text)] mb-3 sm:mb-4">System Overview</h2>
                    <p className="text-sm sm:text-base text-[var(--text-muted)]">Welcome to the Admin Portal. Select a tab to manage agents, templates, or view analytics.</p>
                    <div className="mt-4 sm:mt-6 grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-6">
                        <div className="p-3 sm:p-4 bg-[var(--glass-bg)] rounded-lg sm:rounded-xl border border-[var(--glass-border)]">
                            <h3 className="text-xs sm:text-sm text-[var(--text-muted)]">Active Agents</h3>
                            <p className="text-xl sm:text-2xl font-bold text-[var(--page-text)] mt-1">{agents.length}</p>
                        </div>
                        <div className="p-3 sm:p-4 bg-[var(--glass-bg)] rounded-lg sm:rounded-xl border border-[var(--glass-border)]">
                            <h3 className="text-xs sm:text-sm text-[var(--text-muted)]">Templates</h3>
                            <p className="text-xl sm:text-2xl font-bold text-[var(--page-text)] mt-1">{templates.length}</p>
                        </div>
                        <div className="p-3 sm:p-4 bg-[var(--glass-bg)] rounded-lg sm:rounded-xl border border-[var(--glass-border)]">
                            <h3 className="text-xs sm:text-sm text-[var(--text-muted)]">Generated Forms</h3>
                            <p className="text-xl sm:text-2xl font-bold text-[var(--page-text)] mt-1">{generatedForms.length}</p>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'analytics' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                    <AnalyticsDashboard />
                </motion.div>
            )}

            {activeTab === 'agents' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4 sm:space-y-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                        {agents.map((agent) => (
                            <div key={agent.id} className="bg-[var(--card-bg)] backdrop-blur-xl p-4 sm:p-6 rounded-2xl sm:rounded-3xl shadow-lg border border-[var(--glass-border)] relative overflow-hidden group hover:bg-[var(--glass-bg)] transition-colors">
                                <div className="flex items-center gap-3 sm:gap-4 mb-3 sm:mb-4">
                                    <div className={`p-2 sm:p-3 rounded-xl sm:rounded-2xl ${agent.status === 'Processing' ? 'bg-[var(--bg-info)] text-[var(--color-info)] animate-pulse' : 'bg-[var(--glass-bg)] text-[var(--text-muted)]'}`}>
                                        <Cpu className="h-5 w-5 sm:h-6 sm:w-6" />
                                    </div>
                                    <div>
                                        <h3 className="text-base sm:text-lg font-bold text-[var(--page-text)]">{agent.name}</h3>
                                        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${agent.status === 'Processing' ? 'bg-[var(--bg-info)] text-[var(--color-info)] border border-[var(--color-info)]/20' : 'bg-[var(--glass-bg)] text-[var(--text-muted)] border border-[var(--glass-border)]'}`}>
                                            {agent.status}
                                        </span>
                                    </div>
                                </div>
                                <div className="bg-[var(--glass-bg)] p-3 sm:p-4 rounded-lg sm:rounded-xl border border-[var(--glass-border)]">
                                    <p className="text-xs text-[var(--text-muted)] uppercase tracking-wider mb-1">Current Task</p>
                                    <p className="text-sm font-medium text-[var(--page-text)]">{agent.task}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </motion.div>
            )}

            {activeTab === 'templates' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 sm:space-y-8">
                    {/* Upload Section */}
                    <div className="bg-[var(--card-bg)] backdrop-blur-xl p-6 sm:p-8 md:p-12 rounded-2xl sm:rounded-3xl shadow-lg border border-[var(--glass-border)] text-center relative overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-b from-primary-500/5 to-transparent pointer-events-none" />
                        <div className="max-w-xl mx-auto relative z-10">
                            <div className="mx-auto h-16 w-16 sm:h-20 sm:w-20 bg-gradient-to-br from-primary-500/20 to-teal-500/20 rounded-full flex items-center justify-center mb-4 sm:mb-6 border border-[var(--glass-border)] shadow-inner">
                                <Upload className="h-8 w-8 sm:h-10 sm:w-10 text-primary-400" />
                            </div>
                            <h2 className="text-xl sm:text-2xl font-bold text-[var(--page-text)] mb-2">Upload Form Template</h2>
                            <p className="text-sm sm:text-base text-[var(--text-muted)] mb-6 sm:mb-8">Upload a PDF or DOCX file. Our agents will analyze it and generate an E-Form automatically.</p>

                            <label className="relative inline-flex items-center justify-center px-6 py-3 sm:px-8 sm:py-4 text-base sm:text-lg font-bold text-white bg-primary-600 rounded-xl sm:rounded-2xl overflow-hidden transition-all hover:bg-primary-500 hover:shadow-lg hover:shadow-primary-500/40 cursor-pointer hover:scale-105 active:scale-95 min-h-[48px]">
                                <span>Select File</span>
                                <input type="file" className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" onChange={handleFileUpload} accept=".pdf,.doc,.docx" />
                            </label>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 lg:gap-8">
                        {/* Uploaded Templates List */}
                        <div className="bg-[var(--card-bg)] backdrop-blur-xl rounded-2xl sm:rounded-3xl shadow-lg border border-[var(--glass-border)] overflow-hidden">
                            <div className="px-4 sm:px-6 py-4 sm:py-5 border-b border-[var(--glass-border)] bg-[var(--glass-bg)]">
                                <h3 className="text-base sm:text-lg font-bold text-[var(--page-text)]">Uploaded Templates</h3>
                            </div>
                            <div className="divide-y divide-[var(--glass-border)]">
                                {templates.length > 0 ? (
                                    templates.map((template) => (
                                        <div key={template.id} className="p-3 sm:p-4 flex items-center justify-between gap-2 hover:bg-[var(--glass-bg)] transition-colors">
                                            <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                                                <div className="p-2 bg-[var(--glass-bg)] rounded-lg text-[var(--text-muted)] flex-shrink-0">
                                                    <FileText className="h-4 w-4 sm:h-5 sm:w-5" />
                                                </div>
                                                <div className="min-w-0">
                                                    <p className="text-xs sm:text-sm font-medium text-[var(--page-text)] truncate">{template.name}</p>
                                                    <p className="text-xs text-[var(--text-muted)]">{template.date}</p>
                                                </div>
                                            </div>
                                            <span className={`text-xs font-semibold px-2 py-1 rounded-full whitespace-nowrap flex-shrink-0 ${template.status === 'Converted to E-Form' ? 'bg-[var(--bg-success)] text-[var(--color-success)] border border-[var(--color-success)]/20' : 'bg-[var(--bg-warning)] text-[var(--color-warning)] border border-[var(--color-warning)]/20'}`}>
                                                {template.status}
                                            </span>
                                        </div>
                                    ))
                                ) : (
                                    <div className="p-6 sm:p-8 text-center text-sm sm:text-base text-[var(--text-muted)]">No templates uploaded yet.</div>
                                )}
                            </div>
                        </div>

                        {/* Generated E-Forms List */}
                        <div className="bg-[var(--card-bg)] backdrop-blur-xl rounded-2xl sm:rounded-3xl shadow-lg border border-[var(--glass-border)] overflow-hidden">
                            <div className="px-4 sm:px-6 py-4 sm:py-5 border-b border-[var(--glass-border)] bg-[var(--glass-bg)]">
                                <h3 className="text-base sm:text-lg font-bold text-[var(--page-text)]">Generated E-Forms</h3>
                            </div>
                            <div className="divide-y divide-[var(--glass-border)]">
                                {generatedForms.map((form) => (
                                    <div key={form.id} className="p-3 sm:p-4 flex items-center justify-between gap-2 hover:bg-[var(--glass-bg)] transition-colors">
                                        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                                            <div className="p-2 bg-primary-500/10 rounded-lg text-primary-400 flex-shrink-0">
                                                <FileBox className="h-4 w-4 sm:h-5 sm:w-5" />
                                            </div>
                                            <div className="min-w-0">
                                                <p className="text-xs sm:text-sm font-medium text-[var(--page-text)] truncate">{form.title}</p>
                                                <p className="text-xs text-[var(--text-muted)]">{form.fields.length} Fields Extracted</p>
                                            </div>
                                        </div>
                                        <button className="text-xs font-medium text-primary-400 hover:text-primary-300 bg-primary-500/10 px-3 py-2 rounded-lg border border-primary-500/20 hover:bg-primary-500/20 transition-all whitespace-nowrap flex-shrink-0 min-h-[44px]">Preview</button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </motion.div>
            )}
        </div>
    );
};

export default AdminDashboard;
