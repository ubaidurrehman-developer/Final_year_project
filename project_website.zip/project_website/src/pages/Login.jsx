import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User, Lock, ArrowRight, GraduationCap, ShieldCheck } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

const Login = () => {
    const [activeTab, setActiveTab] = useState('student');
    const navigate = useNavigate();

    const handleLogin = (e) => {
        e.preventDefault();
        // Mock login - redirect based on tab
        if (activeTab === 'student') {
            navigate('/student');
        } else {
            navigate('/admin');
        }
    };

    return (
        <div className="min-h-screen w-full flex items-center justify-center relative overflow-hidden bg-[var(--page-bg)] transition-colors duration-300">
            {/* Animated Background Elements */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
                <div className="absolute top-[-10%] left-[-10%] w-[600px] h-[600px] bg-primary-600 rounded-full blur-[120px] opacity-20 animate-blob" style={{ opacity: 'var(--blob-opacity)' }} />
                <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] bg-teal-600 rounded-full blur-[120px] opacity-20 animate-blob animation-delay-2000" style={{ opacity: 'var(--blob-opacity)' }} />
                <div className="absolute top-[40%] left-[40%] w-[500px] h-[500px] bg-blue-600 rounded-full blur-[120px] opacity-20 animate-blob animation-delay-4000" style={{ opacity: 'var(--blob-opacity)' }} />
            </div>

            {/* Main Card */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="relative z-10 w-full max-w-5xl mx-4 grid grid-cols-1 lg:grid-cols-2 bg-[var(--card-bg)] backdrop-blur-xl border border-[var(--glass-border)] rounded-3xl shadow-2xl overflow-hidden"
            >
                {/* Left Side - Visual (Always Dark for contrast) */}
                <div className="relative hidden lg:flex flex-col justify-between p-12 overflow-hidden bg-slate-900">
                    <div className="absolute inset-0 bg-gradient-to-br from-primary-600/20 to-teal-600/20 z-0" />
                    <div className="absolute inset-0 bg-[url('/login-bg.png')] bg-cover bg-center opacity-40 mix-blend-overlay" />

                    <div className="relative z-10">
                        <div className="flex items-center gap-3 mb-8">
                            <div className="p-2.5 bg-white/10 backdrop-blur-md rounded-xl border border-white/20 shadow-lg">
                                <GraduationCap className="h-8 w-8 text-white" />
                            </div>
                            <span className="text-2xl font-bold text-white tracking-tight">UniPortal</span>
                        </div>

                        <h2 className="text-4xl font-bold text-white mb-6 leading-tight">
                            Welcome to the <br />
                            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-300 to-teal-300">Future of Education</span>
                        </h2>
                        <p className="text-blue-100/80 text-lg leading-relaxed max-w-md">
                            Experience seamless academic management with our AI-powered platform. Streamline your workflow today.
                        </p>
                    </div>

                    <div className="relative z-10 flex gap-4 text-sm text-blue-200/60 font-medium">
                        <span>© 2025 UniPortal</span>
                        <span>•</span>
                        <span>Privacy Policy</span>
                    </div>
                </div>

                {/* Right Side - Login Form */}
                <div className="p-8 sm:p-12 flex flex-col justify-center bg-[var(--glass-bg)]">
                    <div className="mb-8 text-center lg:text-left">
                        <h3 className="text-2xl font-bold text-[var(--page-text)] mb-2">Sign In</h3>
                        <p className="text-[var(--text-muted)]">Access your dashboard using your credentials</p>
                    </div>

                    {/* Tabs */}
                    <div className="flex p-1 bg-[var(--glass-bg)] rounded-xl mb-8 border border-[var(--glass-border)]">
                        <button
                            onClick={() => setActiveTab('student')}
                            className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-medium rounded-lg transition-all duration-200 ${activeTab === 'student'
                                ? 'bg-[var(--page-text)] text-[var(--page-bg)] shadow-md'
                                : 'text-[var(--text-muted)] hover:text-[var(--page-text)]'
                                }`}
                        >
                            <User className="h-4 w-4" />
                            Student
                        </button>
                        <button
                            onClick={() => setActiveTab('admin')}
                            className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-medium rounded-lg transition-all duration-200 ${activeTab === 'admin'
                                ? 'bg-[var(--page-text)] text-[var(--page-bg)] shadow-md'
                                : 'text-[var(--text-muted)] hover:text-[var(--page-text)]'
                                }`}
                        >
                            <ShieldCheck className="h-4 w-4" />
                            Admin
                        </button>
                    </div>

                    {/* Form */}
                    <form onSubmit={handleLogin} className="space-y-5">
                        <div className="space-y-1.5">
                            <label className="text-sm font-medium text-[var(--page-text)] ml-1">Email Address</label>
                            <div className="relative group">
                                <User className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-[var(--text-muted)] group-focus-within:text-primary-400 transition-colors" />
                                <input
                                    type="email"
                                    placeholder={activeTab === 'student' ? "student@university.edu" : "admin@university.edu"}
                                    className="w-full bg-[var(--glass-bg)] border border-[var(--glass-border)] text-[var(--page-text)] rounded-xl px-11 py-3.5 outline-none focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all placeholder:text-[var(--text-muted)]/50"
                                    required
                                />
                            </div>
                        </div>

                        <div className="space-y-1.5">
                            <div className="flex justify-between ml-1">
                                <label className="text-sm font-medium text-[var(--page-text)]">Password</label>
                                <a href="#" className="text-sm font-medium text-primary-400 hover:text-primary-300 transition-colors">Forgot?</a>
                            </div>
                            <div className="relative group">
                                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-[var(--text-muted)] group-focus-within:text-primary-400 transition-colors" />
                                <input
                                    type="password"
                                    placeholder="••••••••"
                                    className="w-full bg-[var(--glass-bg)] border border-[var(--glass-border)] text-[var(--page-text)] rounded-xl px-11 py-3.5 outline-none focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all placeholder:text-[var(--text-muted)]/50"
                                    required
                                />
                            </div>
                        </div>

                        <button
                            type="submit"
                            className="w-full bg-gradient-to-r from-primary-600 to-primary-500 hover:from-primary-500 hover:to-primary-400 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-primary-500/20 hover:shadow-primary-500/40 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 flex items-center justify-center gap-2 group"
                        >
                            Sign In
                            <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
                        </button>
                    </form>

                    <div className="mt-8 text-center">
                        <p className="text-[var(--text-muted)] text-sm">
                            Don't have an account?{' '}
                            <Link to="/register" className="font-semibold text-primary-400 hover:text-primary-300 transition-colors">
                                Apply Now
                            </Link>
                        </p>
                    </div>
                </div>
            </motion.div>
        </div>
    );
};

export default Login;
