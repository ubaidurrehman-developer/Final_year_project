import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileText, Send, Clock, CheckCircle, XCircle, Plus, ChevronRight, Upload } from 'lucide-react';
import { useForms } from '../context/FormContext';

const StudentDashboard = () => {
    const [activeTab, setActiveTab] = useState('dashboard');
    const { forms, generatedForms } = useForms();

    // Filter forms for the "current user" (mocked)
    const myForms = forms.filter(f => f.student === 'Current User' || f.student === 'John Doe');

    const getStatusColor = (status) => {
        switch (status) {
            case 'Approved': return 'text-[var(--color-success)] bg-[var(--bg-success)] border-[var(--color-success)]/20';
            case 'Rejected': return 'text-[var(--color-danger)] bg-[var(--bg-danger)] border-[var(--color-danger)]/20';
            default: return 'text-[var(--color-warning)] bg-[var(--bg-warning)] border-[var(--color-warning)]/20';
        }
    };

    return (
        <div className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 lg:px-8 py-6 sm:py-10">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 sm:mb-8 gap-3 sm:gap-4">
                <div>
                    <h1 className="text-2xl sm:text-3xl font-bold text-[var(--page-text)]">Student Portal</h1>
                    <p className="text-sm sm:text-base text-[var(--text-muted)] mt-1">Manage your academic requests and forms</p>
                </div>
                <button
                    onClick={() => setActiveTab('submit')}
                    className="w-full sm:w-auto flex items-center justify-center gap-2 bg-primary-600 text-white px-4 py-2.5 sm:px-5 sm:py-3 rounded-xl hover:bg-primary-500 hover:shadow-lg hover:shadow-primary-500/30 transition-all duration-300 font-medium border border-white/10 text-sm sm:text-base min-h-[48px]"
                >
                    <Plus className="h-4 w-4 sm:h-5 sm:w-5" />
                    <span>New Submission</span>
                </button>
            </div>

            <AnimatePresence mode="wait">
                {activeTab === 'dashboard' ? (
                    <motion.div
                        key="dashboard"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="space-y-8"
                    >
                        {/* Stats Cards */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
                            {[
                                { label: 'Total Submissions', value: myForms.length, icon: <FileText className="h-6 w-6 text-[var(--color-info)]" />, color: 'bg-[var(--bg-info)] border-[var(--color-info)]/30' },
                                { label: 'Pending', value: myForms.filter(f => f.status === 'Pending').length, icon: <Clock className="h-6 w-6 text-[var(--color-warning)]" />, color: 'bg-[var(--bg-warning)] border-[var(--color-warning)]/30' },
                                { label: 'Approved', value: myForms.filter(f => f.status === 'Approved').length, icon: <CheckCircle className="h-6 w-6 text-[var(--color-success)]" />, color: 'bg-[var(--bg-success)] border-[var(--color-success)]/30' },
                            ].map((stat, index) => (
                                <motion.div
                                    key={index}
                                    whileHover={{ y: -5 }}
                                    className={`${stat.color} backdrop-blur-md p-4 sm:p-6 rounded-2xl sm:rounded-3xl border shadow-lg relative overflow-hidden group`}
                                >
                                    <div className="flex items-center justify-between relative z-10">
                                        <div>
                                            <p className="text-xs sm:text-sm font-medium text-[var(--text-muted)]">{stat.label}</p>
                                            <p className="text-2xl sm:text-3xl font-bold text-[var(--page-text)] mt-1">{stat.value}</p>
                                        </div>
                                        <div className="p-2 sm:p-3 rounded-xl sm:rounded-2xl bg-[var(--glass-bg)] border border-[var(--glass-border)] shadow-inner">
                                            <div className="w-5 h-5 sm:w-6 sm:h-6">{stat.icon}</div>
                                        </div>
                                    </div>
                                </motion.div>
                            ))}
                        </div>

                        {/* Recent Submissions List */}
                        <div className="bg-[var(--card-bg)] backdrop-blur-xl rounded-2xl sm:rounded-3xl shadow-xl border border-[var(--glass-border)] overflow-hidden">
                            <div className="px-4 sm:px-6 md:px-8 py-4 sm:py-6 border-b border-[var(--glass-border)] bg-[var(--glass-bg)]">
                                <h2 className="text-base sm:text-lg font-bold text-[var(--page-text)]">Recent Submissions</h2>
                            </div>
                            <div className="divide-y divide-[var(--glass-border)]">
                                {myForms.length > 0 ? (
                                    myForms.map((form) => (
                                        <div key={form.id} className="p-3 sm:p-4 md:p-6 hover:bg-[var(--glass-bg)] transition-colors group cursor-pointer">
                                            <div className="flex items-center justify-between gap-2">
                                                <div className="flex items-center gap-2 sm:gap-3 md:gap-4 min-w-0">
                                                    <div className={`p-2 sm:p-3 rounded-lg sm:rounded-xl bg-[var(--glass-bg)] text-[var(--color-info)] group-hover:bg-primary-500/20 group-hover:text-primary-300 transition-colors flex-shrink-0`}>
                                                        <FileText className="h-5 w-5 sm:h-6 sm:w-6" />
                                                    </div>
                                                    <div className="min-w-0">
                                                        <h3 className="text-sm sm:text-base font-semibold text-[var(--page-text)] truncate">{form.type}</h3>
                                                        <p className="text-xs sm:text-sm text-[var(--text-muted)] truncate">{form.subject || form.fullName || 'No Subject'} • {form.date}</p>
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-2 sm:gap-4 md:gap-6 flex-shrink-0">
                                                    <div className="text-right hidden md:block">
                                                        <p className="text-xs font-medium text-[var(--text-muted)] uppercase tracking-wider">Current Agent</p>
                                                        <p className="text-sm font-medium text-[var(--page-text)]">{form.agent}</p>
                                                    </div>
                                                    <span className={`px-2 sm:px-3 py-1 rounded-full text-xs font-semibold border whitespace-nowrap ${getStatusColor(form.status)}`}>
                                                        {form.status}
                                                    </span>
                                                    <ChevronRight className="h-4 w-4 sm:h-5 sm:w-5 text-[var(--text-muted)] group-hover:text-[var(--page-text)] transition-colors" />
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <div className="p-6 sm:p-8 md:p-12 text-center text-sm sm:text-base text-[var(--text-muted)]">
                                        No submissions found. Start by creating a new one!
                                    </div>
                                )}
                            </div>
                        </div>
                    </motion.div>
                ) : (
                    <SubmitForm onCancel={() => setActiveTab('dashboard')} onSuccess={() => setActiveTab('dashboard')} generatedForms={generatedForms} />
                )}
            </AnimatePresence>
        </div>
    );
};

const SubmitForm = ({ onCancel, onSuccess, generatedForms }) => {
    const { addForm } = useForms();
    const [selectedFormId, setSelectedFormId] = useState(generatedForms[0]?.id || '');
    const [formData, setFormData] = useState({});

    const selectedForm = generatedForms.find(f => f.id === selectedFormId);

    useEffect(() => {
        if (selectedForm) {
            setFormData({ type: selectedForm.title });
        }
    }, [selectedFormId, selectedForm]);

    const handleSubmit = (e) => {
        e.preventDefault();
        addForm(formData);
        onSuccess();
    };

    const handleInputChange = (name, value) => {
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    return (
        <motion.div
            key="submit"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-[var(--card-bg)] backdrop-blur-2xl rounded-2xl sm:rounded-3xl shadow-2xl border border-[var(--glass-border)] p-4 sm:p-6 md:p-8 max-w-3xl mx-auto"
        >
            <div className="flex justify-between items-center mb-6 sm:mb-8">
                <div>
                    <h2 className="text-xl sm:text-2xl font-bold text-[var(--page-text)]">New Form Submission</h2>
                    <p className="text-[var(--text-muted)] text-xs sm:text-sm">Select a form type and fill out the details</p>
                </div>
                <button onClick={onCancel} className="p-2 hover:bg-[var(--glass-bg)] rounded-full transition-colors text-[var(--text-muted)] hover:text-[var(--page-text)] flex-shrink-0">
                    <XCircle className="h-5 w-5 sm:h-6 sm:w-6" />
                </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
                <div>
                    <label className="block text-xs sm:text-sm font-medium text-[var(--page-text)] mb-2">Form Type</label>
                    <div className="relative">
                        <select
                            value={selectedFormId}
                            onChange={(e) => setSelectedFormId(e.target.value)}
                            className="w-full rounded-lg sm:rounded-xl border border-[var(--glass-border)] bg-[var(--glass-bg)] text-[var(--page-text)] text-sm sm:text-base focus:bg-[var(--glass-bg)] shadow-inner focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all py-2.5 sm:py-3 px-3 sm:px-4 appearance-none"
                        >
                            {generatedForms.map(form => (
                                <option key={form.id} value={form.id} className="bg-[var(--page-bg)] text-[var(--page-text)]">{form.title}</option>
                            ))}
                        </select>
                        <ChevronRight className="absolute right-4 top-1/2 -translate-y-1/2 h-5 w-5 text-[var(--text-muted)] rotate-90 pointer-events-none" />
                    </div>
                </div>

                {selectedForm && (
                    <div className="space-y-4 sm:space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                        {selectedForm.fields.map((field) => (
                            <div key={field.name}>
                                <label className="block text-xs sm:text-sm font-medium text-[var(--page-text)] mb-2">{field.label}</label>
                                {field.type === 'textarea' ? (
                                    <textarea
                                        required={field.required}
                                        onChange={(e) => handleInputChange(field.name, e.target.value)}
                                        className="w-full rounded-lg sm:rounded-xl border border-[var(--glass-border)] bg-[var(--glass-bg)] text-[var(--page-text)] text-sm sm:text-base focus:bg-[var(--glass-bg)] shadow-inner focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all p-3 sm:p-4"
                                        rows={4}
                                    />
                                ) : field.type === 'file' ? (
                                    <div className="mt-1 flex justify-center px-4 sm:px-6 pt-6 sm:pt-8 pb-6 sm:pb-8 border-2 border-[var(--glass-border)] border-dashed rounded-lg sm:rounded-xl hover:border-primary-500/50 hover:bg-primary-500/5 transition-all cursor-pointer group bg-[var(--glass-bg)]">
                                        <div className="space-y-2 text-center">
                                            <div className="mx-auto h-12 w-12 text-[var(--text-muted)] group-hover:text-primary-400 transition-colors">
                                                <Upload className="h-full w-full" />
                                            </div>
                                            <div className="flex text-sm text-[var(--text-muted)] justify-center">
                                                <span className="relative cursor-pointer rounded-md font-medium text-primary-400 hover:text-primary-300">
                                                    Upload a file
                                                </span>
                                                <p className="pl-1">or drag and drop</p>
                                            </div>
                                            <p className="text-xs text-[var(--text-muted)]">PDF, DOC up to 10MB</p>
                                        </div>
                                    </div>
                                ) : (
                                    <input
                                        type={field.type}
                                        required={field.required}
                                        onChange={(e) => handleInputChange(field.name, e.target.value)}
                                        className="w-full rounded-lg sm:rounded-xl border border-[var(--glass-border)] bg-[var(--glass-bg)] text-[var(--page-text)] text-sm sm:text-base focus:bg-[var(--glass-bg)] shadow-inner focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all py-2.5 sm:py-3 px-3 sm:px-4"
                                    />
                                )}
                            </div>
                        ))}
                    </div>
                )}

                <div className="flex flex-col sm:flex-row justify-end gap-3 sm:gap-4 pt-4 sm:pt-6 border-t border-[var(--glass-border)]">
                    <button
                        type="button"
                        onClick={onCancel}
                        className="w-full sm:w-auto px-4 sm:px-6 py-2.5 sm:py-3 border border-[var(--glass-border)] rounded-lg sm:rounded-xl text-[var(--text-muted)] hover:bg-[var(--glass-bg)] font-medium transition-colors text-sm sm:text-base min-h-[48px]"
                    >
                        Cancel
                    </button>
                    <button
                        type="submit"
                        className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 bg-primary-600 text-white rounded-lg sm:rounded-xl hover:bg-primary-500 hover:shadow-lg hover:shadow-primary-500/30 transition-all font-medium text-sm sm:text-base min-h-[48px]"
                    >
                        <Send className="h-4 w-4" />
                        <span>Submit Form</span>
                    </button>
                </div>
            </form>
        </motion.div>
    );
};

export default StudentDashboard;
