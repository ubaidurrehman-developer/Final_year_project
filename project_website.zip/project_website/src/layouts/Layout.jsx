import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShieldCheck, GraduationCap, Sun, Moon, Twitter, Linkedin, Facebook, Instagram, Mail, ArrowRight, Heart } from 'lucide-react';
import Navbar from '../components/Navbar';
import { useTheme } from '../context/ThemeContext';

const Layout = ({ children }) => {
    const location = useLocation();
    const { theme } = useTheme();

    if (location.pathname === '/login') {
        return <>{children}</>;
    }

    return (
        <div className="min-h-screen flex flex-col font-sans text-[var(--page-text)] relative overflow-hidden bg-[var(--page-bg)] transition-colors duration-300 pl-0 md:pl-24 pb-24 md:pb-0">
            {/* Global Background */}
            <div className="fixed inset-0 z-0 pointer-events-none">
                <div className="absolute inset-0 bg-gradient-to-br from-[var(--page-bg)] via-[var(--page-bg)] to-[var(--page-bg)]" />
                <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-primary-600 rounded-full blur-[100px] animate-blob" style={{ opacity: 'var(--blob-opacity)' }} />
                <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-teal-600 rounded-full blur-[100px] animate-blob animation-delay-2000" style={{ opacity: 'var(--blob-opacity)' }} />
                <div className="absolute top-[40%] left-[40%] w-[400px] h-[400px] bg-blue-600 rounded-full blur-[100px] animate-blob animation-delay-4000" style={{ opacity: 'var(--blob-opacity)' }} />
            </div>

            {/* Floating Dock Navbar */}
            <Navbar />

            <main className="flex-grow relative z-10">
                {children}
            </main>

            {/* Premium Footer */}
            <footer className="relative z-10 border-t border-[var(--glass-border)] bg-[var(--glass-bg)] backdrop-blur-xl pt-16 pb-8 mt-20">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
                        {/* Brand Column */}
                        <div className="space-y-6">
                            <Link to="/" className="flex items-center gap-3 group">
                                <div className="p-2 bg-gradient-to-br from-primary-500 to-teal-600 rounded-lg shadow-lg">
                                    <GraduationCap className="h-6 w-6 text-white" />
                                </div>
                                <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-[var(--page-text)] to-[var(--text-muted)]">
                                    UniPortal
                                </span>
                            </Link>
                            <p className="text-[var(--text-muted)] text-sm leading-relaxed">
                                Empowering educational institutions with next-generation AI automation. Streamline workflows, enhance productivity, and focus on what matters most.
                            </p>
                            <div className="flex gap-4">
                                {[Twitter, Linkedin, Facebook, Instagram].map((Icon, i) => (
                                    <a key={i} href="#" className="p-2 rounded-lg bg-[var(--glass-border)] text-[var(--text-muted)] hover:text-[var(--page-text)] hover:bg-primary-500/20 transition-all duration-300">
                                        <Icon className="h-4 w-4" />
                                    </a>
                                ))}
                            </div>
                        </div>

                        {/* Quick Links */}
                        <div>
                            <h3 className="text-[var(--page-text)] font-bold mb-6">Platform</h3>
                            <ul className="space-y-4">
                                {['Student Portal', 'Admin Dashboard', 'Agent Monitor', 'Template Manager'].map((item) => (
                                    <li key={item}>
                                        <a href="#" className="text-[var(--text-muted)] hover:text-primary-400 transition-colors text-sm flex items-center gap-2 group">
                                            <span className="w-1 h-1 rounded-full bg-primary-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                                            {item}
                                        </a>
                                    </li>
                                ))}
                            </ul>
                        </div>

                        {/* Resources */}
                        <div>
                            <h3 className="text-[var(--page-text)] font-bold mb-6">Resources</h3>
                            <ul className="space-y-4">
                                {['Documentation', 'API Reference', 'Community', 'Help Center'].map((item) => (
                                    <li key={item}>
                                        <a href="#" className="text-[var(--text-muted)] hover:text-primary-400 transition-colors text-sm flex items-center gap-2 group">
                                            <span className="w-1 h-1 rounded-full bg-primary-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                                            {item}
                                        </a>
                                    </li>
                                ))}
                            </ul>
                        </div>

                        {/* Newsletter */}
                        <div>
                            <h3 className="text-[var(--page-text)] font-bold mb-6">Stay Updated</h3>
                            <p className="text-[var(--text-muted)] text-sm mb-4">
                                Subscribe to our newsletter for the latest updates and features.
                            </p>
                            <div className="space-y-3">
                                <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--text-muted)]" />
                                    <input
                                        type="email"
                                        placeholder="Enter your email"
                                        className="w-full bg-[var(--card-bg)] border border-[var(--glass-border)] rounded-xl py-2.5 pl-10 pr-4 text-sm text-[var(--page-text)] placeholder:text-[var(--text-muted)] focus:border-primary-500 focus:ring-1 focus:ring-primary-500 outline-none transition-all"
                                    />
                                </div>
                                <button className="w-full bg-primary-600 hover:bg-primary-500 text-white font-medium py-2.5 rounded-xl transition-all shadow-lg shadow-primary-500/20 flex items-center justify-center gap-2 group">
                                    Subscribe
                                    <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                                </button>
                            </div>
                        </div>
                    </div>

                    <div className="pt-8 border-t border-[var(--glass-border)] flex flex-col md:flex-row justify-between items-center gap-4">
                        <div className="flex items-center gap-2 text-sm text-[var(--text-muted)]">
                            <span>© 2025 UniPortal. Made with</span>
                            <Heart className="h-4 w-4 text-red-500 fill-red-500 animate-pulse" />
                            <span>for Education.</span>
                        </div>
                        <div className="flex gap-8 text-sm text-[var(--text-muted)]">
                            <a href="#" className="hover:text-[var(--page-text)] transition-colors">Privacy Policy</a>
                            <a href="#" className="hover:text-[var(--page-text)] transition-colors">Terms of Service</a>
                            <a href="#" className="hover:text-[var(--page-text)] transition-colors">Cookie Policy</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    );
};

export default Layout;
