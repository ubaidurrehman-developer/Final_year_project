import React, { createContext, useContext, useState, useEffect } from 'react';

const FormContext = createContext();

export const useForms = () => {
    const context = useContext(FormContext);
    if (!context) {
        throw new Error('useForms must be used within a FormProvider');
    }
    return context;
};

export const FormProvider = ({ children }) => {
    // Initial mock data
    const initialForms = [
        { id: 1, student: 'John Doe', type: 'Leave Application', subject: 'Sick Leave', date: '2025-10-24', status: 'Pending', priority: 'High', agent: 'Faculty Agent', description: 'I am down with fever.' },
        { id: 2, student: 'Jane Smith', type: 'Project Proposal', subject: 'AI Research', date: '2025-10-24', status: 'Approved', priority: 'Medium', agent: 'HOD Agent', description: 'Proposal for FYP.' },
        { id: 3, student: 'Mike Johnson', type: 'Complaint', subject: 'Lab Equipment', date: '2025-10-23', status: 'In Review', priority: 'High', agent: 'System Admin', description: 'PC not working.' },
        { id: 4, student: 'Sarah Wilson', type: 'Course Withdrawal', subject: 'Drop Math', date: '2025-10-22', status: 'Rejected', priority: 'Low', agent: 'Registrar', description: 'Too difficult.' },
    ];

    const [forms, setForms] = useState(() => {
        const saved = localStorage.getItem('forms');
        return saved ? JSON.parse(saved) : initialForms;
    });

    useEffect(() => {
        localStorage.setItem('forms', JSON.stringify(forms));
    }, [forms]);

    const [stats, setStats] = useState({
        total: 0,
        pending: 0,
        approved: 0,
        rejected: 0,
    });

    // Update stats whenever forms change
    useEffect(() => {
        const newStats = forms.reduce((acc, form) => {
            acc.total++;
            if (form.status === 'Pending') acc.pending++;
            if (form.status === 'Approved') acc.approved++;
            if (form.status === 'Rejected') acc.rejected++;
            return acc;
        }, { total: 0, pending: 0, approved: 0, rejected: 0 });
        setStats(newStats);
    }, [forms]);

    // Agent and Template State
    const [agents, setAgents] = useState([
        { id: 1, name: 'Document Parser Agent', status: 'Idle', task: 'Waiting for templates...' },
        { id: 2, name: 'Form Generator Agent', status: 'Idle', task: 'Waiting for parsed data...' },
        { id: 3, name: 'Validation Agent', status: 'Idle', task: 'Monitoring submissions...' },
    ]);

    const [templates, setTemplates] = useState([]);
    const [generatedForms, setGeneratedForms] = useState(() => {
        const saved = localStorage.getItem('generatedForms');
        return saved ? JSON.parse(saved) : [
            {
                id: 'default-1',
                title: 'Leave Application',
                fields: [
                    { name: 'subject', label: 'Subject', type: 'text', required: true },
                    { name: 'description', label: 'Reason', type: 'textarea', required: true },
                    { name: 'startDate', label: 'Start Date', type: 'date', required: true },
                    { name: 'endDate', label: 'End Date', type: 'date', required: true }
                ]
            }
        ];
    });

    useEffect(() => {
        localStorage.setItem('generatedForms', JSON.stringify(generatedForms));
    }, [generatedForms]);

    // Simulate Agent Workflow
    const uploadTemplate = (file) => {
        const newTemplate = { id: Date.now(), name: file.name, status: 'Uploaded', date: new Date().toLocaleDateString() };
        setTemplates(prev => [newTemplate, ...prev]);

        // Trigger Agent 1: Document Parser
        updateAgentStatus(1, 'Processing', `Parsing ${file.name}...`);

        setTimeout(() => {
            // Agent 1 finishes
            updateAgentStatus(1, 'Idle', 'Waiting for templates...');
            updateTemplateStatus(newTemplate.id, 'Parsed');

            // Trigger Agent 2: Form Generator
            updateAgentStatus(2, 'Processing', `Generating form structure for ${file.name}...`);

            setTimeout(() => {
                // Agent 2 finishes
                const newForm = generateMockFormSchema(file.name);
                setGeneratedForms(prev => [...prev, newForm]);
                updateAgentStatus(2, 'Idle', 'Waiting for parsed data...');
                updateTemplateStatus(newTemplate.id, 'Converted to E-Form');
            }, 2000);

        }, 2000);
    };

    const updateAgentStatus = (id, status, task) => {
        setAgents(prev => prev.map(a => a.id === id ? { ...a, status, task } : a));
    };

    const updateTemplateStatus = (id, status) => {
        setTemplates(prev => prev.map(t => t.id === id ? { ...t, status } : t));
    };

    const generateMockFormSchema = (filename) => {
        // Simple mock logic to generate fields based on filename
        const title = filename.split('.')[0].replace(/-/g, ' ');
        return {
            id: Date.now(),
            title: title.charAt(0).toUpperCase() + title.slice(1),
            fields: [
                { name: 'fullName', label: 'Full Name', type: 'text', required: true },
                { name: 'idNumber', label: 'Student ID', type: 'text', required: true },
                { name: 'details', label: 'Details', type: 'textarea', required: true },
                { name: 'attachment', label: 'Supporting Documents', type: 'file', required: false }
            ]
        };
    };

    const addForm = (formData) => {
        const newForm = {
            id: forms.length + 1,
            student: 'Current User', // Mocking logged-in user
            date: new Date().toISOString().split('T')[0],
            status: 'Pending',
            priority: 'Medium', // Default priority
            agent: 'System Agent', // Initial routing
            ...formData,
        };
        setForms([newForm, ...forms]);
    };

    const updateFormStatus = (id, newStatus) => {
        setForms(forms.map(form =>
            form.id === id ? { ...form, status: newStatus } : form
        ));
    };

    const deleteForm = (id) => {
        setForms(forms.filter(form => form.id !== id));
    };

    return (
        <FormContext.Provider value={{
            forms, stats, addForm, updateFormStatus, deleteForm,
            agents, templates, generatedForms, uploadTemplate
        }}>
            {children}
        </FormContext.Provider>
    );
};
